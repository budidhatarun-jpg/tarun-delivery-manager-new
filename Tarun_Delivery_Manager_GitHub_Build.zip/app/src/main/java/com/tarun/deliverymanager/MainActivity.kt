package com.tarun.deliverymanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class ParcelRow(
    val id: Long,
    val tracking: String,
    val area: String,
    val address: String,
    val status: String = "Pending"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { DeliveryHome() } }
    }
}

@Composable
fun DeliveryHome() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("delivery_manager", 0) }
    var rows by remember { mutableStateOf(loadRows(prefs.getString("parcels", "[]") ?: "[]")) }
    var message by remember { mutableStateOf("Upload screenshots or add a parcel manually.") }
    var target by remember { mutableIntStateOf(prefs.getInt("target", 40)) }
    var hub by remember { mutableStateOf(prefs.getString("hub", "Nallakunta Hub") ?: "Nallakunta Hub") }
    var showAdd by remember { mutableStateOf(false) }
    var newTracking by remember { mutableStateOf("") }
    var newAddress by remember { mutableStateOf("") }
    var newArea by remember { mutableStateOf("Needs review") }
    var filter by remember { mutableStateOf("All") }
    var busy by remember { mutableStateOf(false) }

    fun save(updated: List<ParcelRow>) {
        rows = updated
        prefs.edit().putString("parcels", saveRows(updated)).apply()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            busy = true
            message = "Reading ${uris.size} screenshot(s)…"
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            val results = mutableListOf<String>()
            var finished = 0
            uris.forEach { uri ->
                try {
                    recognizer.process(InputImage.fromFilePath(context, uri))
                        .addOnSuccessListener { results.add(it.text) }
                        .addOnFailureListener { message = "A screenshot could not be read. Try a clearer image." }
                        .addOnCompleteListener {
                            finished++
                            if (finished == uris.size) {
                                val extracted = parseCandidates(results.joinToString("\n"))
                                val existingKeys = rows.map { it.address.normalized() }.toSet()
                                val fresh = extracted.filter { it.address.normalized() !in existingKeys }
                                save(rows + fresh)
                                message = "Scanned ${uris.size} image(s): ${fresh.size} new address candidate(s). Review every result."
                                busy = false
                                recognizer.close()
                            }
                        }
                } catch (_: Exception) {
                    finished++
                    if (finished == uris.size) {
                        busy = false
                        message = "Some images could not be opened. Please try again."
                        recognizer.close()
                    }
                }
            }
        }
    }

    val visible = rows.filter { filter == "All" || it.status == filter }
    val areaOrder = listOf("Nallakunta", "Ramnagar", "Musheerabad", "Other / review")
    val grouped = visible.sortedWith(compareBy<ParcelRow> {
        areaOrder.indexOf(it.area).let { n -> if (n < 0) 99 else n }
    }.thenBy { it.address.lowercase() })

    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Tarun Delivery Manager", style = MaterialTheme.typography.headlineSmall)
            Text("Version 2.0 • Personal delivery organizer", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("Total", rows.size.toString(), Modifier.weight(1f))
                Metric("Pending", rows.count { it.status == "Pending" }.toString(), Modifier.weight(1f))
                Metric("Done", rows.count { it.status == "Delivered" }.toString(), Modifier.weight(1f))
            }
            OutlinedTextField(
                value = hub, onValueChange = { hub = it; prefs.edit().putString("hub", it).apply() },
                label = { Text("Starting hub") }, modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            OutlinedTextField(
                value = target.toString(),
                onValueChange = { it.toIntOrNull()?.let { n -> target = n; prefs.edit().putInt("target", n).apply() } },
                label = { Text("Daily parcel target") }, modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            LinearProgressIndicator(
                progress = { if (target > 0) (rows.count { it.status == "Delivered" }.toFloat() / target).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth()
            )
            Text("${rows.count { it.status == "Delivered" }} / $target delivered")
            Button(onClick = { picker.launch("image/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Scanning screenshots…" else "Upload multiple screenshots")
            }
            OutlinedButton(onClick = { showAdd = !showAdd }, modifier = Modifier.fillMaxWidth()) {
                Text(if (showAdd) "Close manual entry" else "Add parcel manually")
            }
            if (showAdd) {
                OutlinedTextField(newTracking, { newTracking = it }, label = { Text("Tracking / parcel ID (optional)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(newAddress, { newAddress = it }, label = { Text("Full address / landmark") }, modifier = Modifier.fillMaxWidth())
                AreaPicker(newArea) { newArea = it }
                Button(onClick = {
                    if (newAddress.isNotBlank()) {
                        save(rows + ParcelRow(System.currentTimeMillis(), newTracking.trim(), newArea, newAddress.trim()))
                        newTracking = ""; newAddress = ""; showAdd = false
                        message = "Parcel added."
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Save parcel") }
            }
            Text(message, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("All", "Pending", "Delivered", "Failed").forEach { item ->
                    FilterChip(selected = filter == item, onClick = { filter = item }, label = { Text(item) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { shareList(context, rows) },
                    enabled = rows.isNotEmpty(), modifier = Modifier.weight(1f)
                ) { Text("Share / export list") }
                OutlinedButton(
                    onClick = { openAreaRoute(context, hub, rows.filter { it.status == "Pending" }) },
                    enabled = rows.any { it.status == "Pending" }, modifier = Modifier.weight(1f)
                ) { Text("Open route in Maps") }
            }
            Text("Parcel list • review OCR addresses before delivery", style = MaterialTheme.typography.titleMedium)
            if (grouped.isEmpty()) {
                Text("No parcels in this filter.")
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(grouped, key = { it.id }) { parcel ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("${parcel.area}  •  ${parcel.status}", style = MaterialTheme.typography.titleSmall)
                                if (parcel.tracking.isNotBlank()) Text("ID: ${parcel.tracking}", style = MaterialTheme.typography.labelSmall)
                                Text(parcel.address)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    TextButton(onClick = { save(rows.map { if (it.id == parcel.id) it.copy(status = "Delivered") else it }) }) { Text("Delivered") }
                                    TextButton(onClick = { save(rows.map { if (it.id == parcel.id) it.copy(status = "Failed") else it }) }) { Text("Failed") }
                                    TextButton(onClick = { save(rows.filterNot { it.id == parcel.id }) }) { Text("Delete") }
                                }
                            }
                        }
                    }
                }
            }
            Text("Maps opens a suggested multi-stop driving route, not a guaranteed fastest route. Confirm every stop in your official delivery app.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(10.dp)) { Text(value, style = MaterialTheme.typography.headlineMedium); Text(label) } }
}

@Composable
fun AreaPicker(selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text("Area: $selected") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            listOf("Nallakunta", "Ramnagar", "Musheerabad", "Other / review").forEach {
                DropdownMenuItem(text = { Text(it) }, onClick = { onSelected(it); expanded = false })
            }
        }
    }
}

private fun parseCandidates(text: String): List<ParcelRow> {
    val lines = text.lines().map { it.replace(Regex("\\s+"), " ").trim() }
        .filter { it.length >= 10 }
    val localityNames = listOf("Nallakunta", "Ramnagar", "Musheerabad")
    val trackingRegex = Regex("""(?i)\b(?:OD|FM|FK|SHP)[A-Z0-9]{8,}\b""")
    return lines.mapNotNull { line ->
        val area = localityNames.firstOrNull { line.contains(it, true) } ?: "Other / review"
        val looksLikeAddress = line.any { it.isDigit() } ||
            line.contains("road", true) || line.contains("street", true) ||
            line.contains("lane", true) || line.contains("nagar", true) ||
            line.contains("colony", true) || line.contains("hyderabad", true) ||
            area != "Other / review"
        if (looksLikeAddress) {
            ParcelRow(System.currentTimeMillis() + line.hashCode(), trackingRegex.find(line)?.value ?: "", area, line)
        } else null
    }.distinctBy { it.address.normalized() }
}

private fun String.normalized() = lowercase().replace(Regex("[^a-z0-9]"), "")

private fun saveRows(rows: List<ParcelRow>): String {
    val array = JSONArray()
    rows.forEach {
        array.put(JSONObject().put("id", it.id).put("tracking", it.tracking)
            .put("area", it.area).put("address", it.address).put("status", it.status))
    }
    return array.toString()
}

private fun loadRows(json: String): List<ParcelRow> = try {
    val a = JSONArray(json)
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        ParcelRow(o.optLong("id"), o.optString("tracking"), o.optString("area"),
            o.optString("address"), o.optString("status", "Pending"))
    }
} catch (_: Exception) { emptyList() }

private fun shareList(context: android.content.Context, rows: List<ParcelRow>) {
    val body = rows.joinToString("\n") { "${it.status} | ${it.area} | ${it.tracking} | ${it.address}" }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Tarun Delivery Manager parcel list")
        putExtra(Intent.EXTRA_TEXT, body)
    }
    context.startActivity(Intent.createChooser(intent, "Share parcel list"))
}

private fun openAreaRoute(context: android.content.Context, hub: String, parcels: List<ParcelRow>) {
    val ordered = parcels.sortedWith(compareBy<ParcelRow> {
        listOf("Nallakunta", "Ramnagar", "Musheerabad").indexOf(it.area).let { n -> if (n < 0) 99 else n }
    }.thenBy { it.address.lowercase() }).take(9)
    if (ordered.isEmpty()) return
    val destination = ordered.last().address + ", Hyderabad, India"
    val waypoints = ordered.dropLast(1).joinToString("|") { it.address + ", Hyderabad, India" }
    val url = buildString {
        append("https://www.google.com/maps/dir/?api=1")
        append("&origin=").append(URLEncoder.encode(hub + ", Hyderabad, India", "UTF-8"))
        append("&destination=").append(URLEncoder.encode(destination, "UTF-8"))
        if (waypoints.isNotBlank()) append("&waypoints=").append(URLEncoder.encode(waypoints, "UTF-8"))
        append("&travelmode=driving")
    }
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}
